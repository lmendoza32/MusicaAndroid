package com.example.musica

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    var mMediaPlayer:MediaPlayer?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var botonPlay = findViewById<Button>(R.id.buttonPlay) as Button
        var botonStop = findViewById<Button>(R.id.buttonStop) as Button

        botonPlay.setOnClickListener {
            playSound()
        }
        botonStop.setOnClickListener {
            stopSound()
        }
    }
    fun playSound()
    {
        if (mMediaPlayer==null)
        {
            mMediaPlayer = MediaPlayer.create(this,R.raw.sam)
            mMediaPlayer!!.isLooping = true
            mMediaPlayer!!.start()
        }else
        {
            mMediaPlayer!!.start()
        }
    }
    fun stopSound()
    {
        if(mMediaPlayer!=null)
        {
            mMediaPlayer!!.stop()
            mMediaPlayer!!.release()
            mMediaPlayer = null
        }
    }
    override fun onStop()
    {
        super.onStop()
        if(mMediaPlayer!=null)
        {
            mMediaPlayer!!.release()
            mMediaPlayer=null
        }
    }
}